sap.ui.define(["mt/fin/ap/zhe/controller/BaseController"],function(e){"use strict";return e.extend("mt.fin.ap.zhe.controller.App",{})});
//# sourceMappingURL=App.controller.js.map