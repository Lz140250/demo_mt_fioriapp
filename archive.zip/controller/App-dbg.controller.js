sap.ui.define([
    "mt/fin/ap/zhe/controller/BaseController"
], function(Controller) {
    'use strict';
    return Controller.extend("mt.fin.ap.zhe.controller.App", {
       
    })
   
});